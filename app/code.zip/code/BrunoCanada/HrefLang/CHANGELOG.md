# Magento 2 HREF LANG SEO with Multi Store Support Changelog

## 1.1.1 - 2021-02-09
- Fix Composer and README, add CHANGELOG file #3

## 1.1.0 - 2021-02-09
- Update README and License files #2

## 1.0.0 - 2021-02-09
- Make the module usable with Composer install #1

## 0.1.0 - 2019-12-08
- Initial release