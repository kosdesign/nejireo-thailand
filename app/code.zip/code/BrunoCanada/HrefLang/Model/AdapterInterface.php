<?php


namespace BrunoCanada\HrefLang\Model;

interface AdapterInterface
{
    /**
     * @return \BrunoCanada\HrefLang\Model\Property
     */
    public function getProperty();
}
