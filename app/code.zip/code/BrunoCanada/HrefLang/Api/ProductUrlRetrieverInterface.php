<?php
namespace BrunoCanada\HrefLang\Api;

interface ProductUrlRetrieverInterface extends UrlRetrieverInterface
{
}
