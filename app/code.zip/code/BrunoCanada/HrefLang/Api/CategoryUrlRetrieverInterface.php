<?php
namespace BrunoCanada\HrefLang\Api;

interface CategoryUrlRetrieverInterface extends UrlRetrieverInterface
{
}
