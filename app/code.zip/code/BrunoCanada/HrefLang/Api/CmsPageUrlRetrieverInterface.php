<?php
namespace BrunoCanada\HrefLang\Api;

interface CmsPageUrlRetrieverInterface extends UrlRetrieverInterface
{
}
