require([
    "jquery"
    ], function($){
		$(document).ready(function() {
			$('form#frm_eGHL_payment').submit();
		});
   });