require([
    'jquery',
	'mage/url'
    ], function($,urlBuilder){
		'use strict';
		$(document).ready(function() {
			/*
			var URL_logo = urlBuilder.build('eghlgw/Index/Logo');
			var tid = setInterval(function(){
				if($('#eghl_img').length){
					$('#eghl_img').attr('src',URL_logo);
					clearInterval( tid );
				}
			}, 1000);
			*/
		});
		
   });