This software uses Open Source software. See the license information for these projects below.

Project: https://gist.github.com/cedricblondeau/6174911fb4bba6cb4943

No License
