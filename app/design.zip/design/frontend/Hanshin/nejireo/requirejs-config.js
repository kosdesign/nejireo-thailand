var config = {
    map: {
        "*": {
            niceScroll: 'js/jquery.nicescroll',
            slick: 'js/library/slick.min',
            rtResponsiveTables: 'js/library/jquery.rtResponsiveTables.min',
            matchHeight: 'js/library/jquery.matchHeight-min'
        }
    }
};
