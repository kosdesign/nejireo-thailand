var config = {
    map: {
        "*": {
            kosCategoryScroll: 'Kos_CatalogExtend/js/categoryScroll'
        }
    }
};
