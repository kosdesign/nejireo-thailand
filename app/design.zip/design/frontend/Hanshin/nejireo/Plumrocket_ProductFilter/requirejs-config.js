var config = {
    config: {
        mixins: {
            'Plumrocket_ProductFilter/js/init': {
                'Plumrocket_ProductFilter/js/init-mixin': true
            },
            'Plumrocket_ProductFilter/js/model/prproductfilter': {
                'Plumrocket_ProductFilter/js/model/prproductfilter-mixin': true
            }
        }
    }
};